"""
Enhanced training system with improved reliability and data augmentation
Provides better model performance even with limited initial data
"""

import numpy as np
import cv2
from PIL import Image, ImageEnhance, ImageFilter
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.svm import SVC
from sklearn.neural_network import MLPClassifier
from sklearn.preprocessing import StandardScaler, RobustScaler
from sklearn.model_selection import StratifiedKFold, GridSearchCV
from sklearn.metrics import classification_report, confusion_matrix, roc_auc_score, roc_curve
from sklearn.feature_selection import SelectKBest, f_classif
import joblib
import matplotlib.pyplot as plt
import seaborn as sns
from pathlib import Path
import json
from datetime import datetime
import warnings
warnings.filterwarnings('ignore')

class EnhancedHashimotoTrainer:
    def __init__(self, data_dir, output_dir="models"):
        """
        Enhanced trainer with improved reliability techniques
        """
        self.data_dir = Path(data_dir)
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(exist_ok=True)
        
        # Enhanced model ensemble
        self.models = {
            'random_forest': RandomForestClassifier(
                n_estimators=300,
                max_depth=20,
                min_samples_split=3,
                min_samples_leaf=1,
                max_features='sqrt',
                random_state=42,
                class_weight='balanced',
                n_jobs=-1
            ),
            'gradient_boosting': GradientBoostingClassifier(
                n_estimators=200,
                learning_rate=0.1,
                max_depth=6,
                random_state=42
            ),
            'svm': SVC(
                kernel='rbf',
                probability=True,
                class_weight='balanced',
                random_state=42
            ),
            'neural_network': MLPClassifier(
                hidden_layer_sizes=(128, 64, 32),
                max_iter=500,
                random_state=42,
                early_stopping=True
            )
        }
        
        self.scalers = {
            'standard': StandardScaler(),
            'robust': RobustScaler()
        }
        
        self.feature_names = []
        self.best_scaler = None
        self.best_model = None
        
    def augment_image(self, image, augmentation_type):
        """
        Advanced data augmentation for medical images
        """
        if isinstance(image, str):
            image = Image.open(image)
        
        augmented_images = []
        
        if augmentation_type == 'rotation':
            # Multiple rotation angles
            for angle in [-10, -5, 5, 10]:
                rotated = image.rotate(angle, fillcolor=(0, 0, 0))
                augmented_images.append(rotated)
        
        elif augmentation_type == 'brightness':
            # Brightness variations
            enhancer = ImageEnhance.Brightness(image)
            for factor in [0.8, 0.9, 1.1, 1.2]:
                bright_img = enhancer.enhance(factor)
                augmented_images.append(bright_img)
        
        elif augmentation_type == 'contrast':
            # Contrast variations
            enhancer = ImageEnhance.Contrast(image)
            for factor in [0.8, 0.9, 1.1, 1.2]:
                contrast_img = enhancer.enhance(factor)
                augmented_images.append(contrast_img)
        
        elif augmentation_type == 'noise':
            # Add different types of noise
            img_array = np.array(image)
            
            # Gaussian noise
            gaussian_noise = np.random.normal(0, 10, img_array.shape)
            noisy1 = np.clip(img_array + gaussian_noise, 0, 255).astype(np.uint8)
            augmented_images.append(Image.fromarray(noisy1))
            
            # Salt and pepper noise
            s_vs_p = 0.5
            amount = 0.02
            noisy2 = np.copy(img_array)
            num_salt = np.ceil(amount * img_array.size * s_vs_p)
            coords = [np.random.randint(0, i - 1, int(num_salt)) for i in img_array.shape[:2]]
            noisy2[coords] = 255
            
            num_pepper = np.ceil(amount * img_array.size * (1. - s_vs_p))
            coords = [np.random.randint(0, i - 1, int(num_pepper)) for i in img_array.shape[:2]]
            noisy2[coords] = 0
            augmented_images.append(Image.fromarray(noisy2))
        
        elif augmentation_type == 'blur':
            # Different blur effects
            for radius in [0.5, 1.0]:
                blurred = image.filter(ImageFilter.GaussianBlur(radius=radius))
                augmented_images.append(blurred)
        
        return augmented_images
    
    def extract_enhanced_features(self, image_path):
        """
        Extract comprehensive features with improved reliability
        """
        try:
            # Load and preprocess image
            image = cv2.imread(str(image_path))
            if image is None:
                raise ValueError(f"Could not load image: {image_path}")
            
            # Convert to RGB and resize
            image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
            image = cv2.resize(image, (224, 224))
            gray = cv2.cvtColor(image, cv2.COLOR_RGB2GRAY)
            
            features = []
            feature_names = []
            
            # 1. Enhanced Statistical Features
            stats = [
                ('mean', np.mean(gray)),
                ('std', np.std(gray)),
                ('var', np.var(gray)),
                ('median', np.median(gray)),
                ('min', np.min(gray)),
                ('max', np.max(gray)),
                ('range', np.max(gray) - np.min(gray)),
                ('q25', np.percentile(gray, 25)),
                ('q75', np.percentile(gray, 75)),
                ('iqr', np.percentile(gray, 75) - np.percentile(gray, 25)),
                ('skewness', self._calculate_skewness(gray)),
                ('kurtosis', self._calculate_kurtosis(gray)),
                ('entropy', self._calculate_entropy(gray))
            ]
            
            for name, value in stats:
                features.append(value)
                feature_names.append(f'stat_{name}')
            
            # 2. Multi-scale Texture Features
            for scale in [3, 5, 7]:
                grad_x = cv2.Sobel(gray, cv2.CV_64F, 1, 0, ksize=scale)
                grad_y = cv2.Sobel(gray, cv2.CV_64F, 0, 1, ksize=scale)
                grad_mag = np.sqrt(grad_x**2 + grad_y**2)
                
                texture_features = [
                    (f'grad_x_mean_s{scale}', np.mean(np.abs(grad_x))),
                    (f'grad_y_mean_s{scale}', np.mean(np.abs(grad_y))),
                    (f'grad_mag_mean_s{scale}', np.mean(grad_mag)),
                    (f'grad_mag_std_s{scale}', np.std(grad_mag))
                ]
                
                for name, value in texture_features:
                    features.append(value)
                    feature_names.append(f'texture_{name}')
            
            # 3. Enhanced Edge Features
            edges = cv2.Canny(gray, 50, 150)
            edge_features = [
                ('edge_density', np.sum(edges > 0) / edges.size),
                ('edge_mean_intensity', np.mean(edges[edges > 0]) if np.any(edges > 0) else 0),
                ('edge_std_intensity', np.std(edges[edges > 0]) if np.any(edges > 0) else 0)
            ]
            
            for name, value in edge_features:
                features.append(value)
                feature_names.append(f'edge_{name}')
            
            # 4. Multi-bin Histogram Features
            for bins in [16, 32, 64]:
                hist, _ = np.histogram(gray, bins=bins, range=(0, 256))
                hist = hist / np.sum(hist) if np.sum(hist) > 0 else hist
                
                for i, h in enumerate(hist[:min(8, len(hist))]):
                    features.append(h)
                    feature_names.append(f'hist_{bins}bins_bin{i}')
            
            # 5. Fourier Transform Features
            f_transform = np.fft.fft2(gray)
            f_shift = np.fft.fftshift(f_transform)
            magnitude_spectrum = np.log(np.abs(f_shift) + 1)
            
            freq_features = [
                ('freq_mean', np.mean(magnitude_spectrum)),
                ('freq_std', np.std(magnitude_spectrum)),
                ('freq_energy', np.sum(magnitude_spectrum**2))
            ]
            
            for name, value in freq_features:
                features.append(value)
                feature_names.append(f'freq_{name}')
            
            # 6. Co-occurrence Matrix Features
            glcm_features = self._calculate_glcm_features(gray)
            for i, feature in enumerate(glcm_features):
                features.append(feature)
                feature_names.append(f'glcm_feature_{i}')
            
            # 7. Wavelet Transform Features (simplified)
            wavelet_features = self._calculate_wavelet_features(gray)
            for i, feature in enumerate(wavelet_features):
                features.append(feature)
                feature_names.append(f'wavelet_feature_{i}')
            
            # Store feature names for first image
            if not self.feature_names:
                self.feature_names = feature_names
            
            return np.array(features)
            
        except Exception as e:
            print(f"Error extracting features from {image_path}: {e}")
            return np.zeros(len(self.feature_names) if self.feature_names else 200)
    
    def _calculate_entropy(self, image):
        """Calculate image entropy"""
        hist, _ = np.histogram(image, bins=256, range=(0, 256))
        hist = hist / np.sum(hist)
        hist = hist[hist > 0]  # Remove zeros
        return -np.sum(hist * np.log2(hist))
    
    def _calculate_glcm_features(self, image):
        """Calculate Gray Level Co-occurrence Matrix features (simplified)"""
        # Simplified GLCM calculation
        glcm = np.zeros((256, 256))
        
        for i in range(image.shape[0] - 1):
            for j in range(image.shape[1] - 1):
                pixel1 = image[i, j]
                pixel2 = image[i, j + 1]  # Right neighbor
                glcm[pixel1, pixel2] += 1
        
        # Normalize
        glcm = glcm / np.sum(glcm) if np.sum(glcm) > 0 else glcm
        
        # Calculate features
        contrast = np.sum((np.arange(256)[:, None] - np.arange(256)[None, :]) ** 2 * glcm)
        homogeneity = np.sum(glcm / (1 + (np.arange(256)[:, None] - np.arange(256)[None, :]) ** 2))
        energy = np.sum(glcm ** 2)
        correlation = np.sum((np.arange(256)[:, None] * np.arange(256)[None, :] * glcm))
        
        return [contrast, homogeneity, energy, correlation]
    
    def _calculate_wavelet_features(self, image):
        """Calculate simplified wavelet transform features"""
        # Simple approximation using different kernel convolutions
        kernels = [
            np.array([[-1, 0, 1], [-1, 0, 1], [-1, 0, 1]]),  # Vertical
            np.array([[-1, -1, -1], [0, 0, 0], [1, 1, 1]]),  # Horizontal
            np.array([[-1, 0, 1], [0, 0, 0], [1, 0, -1]]),   # Diagonal
        ]
        
        features = []
        for kernel in kernels:
            convolved = cv2.filter2D(image.astype(np.float32), -1, kernel)
            features.extend([
                np.mean(convolved),
                np.std(convolved),
                np.mean(np.abs(convolved))
            ])
        
        return features
    
    def _calculate_skewness(self, image):
        """Calculate skewness"""
        mean_val = np.mean(image)
        std_val = np.std(image)
        if std_val == 0:
            return 0
        return np.mean(((image - mean_val) / std_val) ** 3)
    
    def _calculate_kurtosis(self, image):
        """Calculate kurtosis"""
        mean_val = np.mean(image)
        std_val = np.std(image)
        if std_val == 0:
            return 0
        return np.mean(((image - mean_val) / std_val) ** 4) - 3
    
    def load_and_augment_dataset(self):
        """
        Load dataset with data augmentation for better reliability
        """
        print("Loading dataset with augmentation...")
        
        features_list = []
        labels_list = []
        
        # Load normal images
        normal_dir = self.data_dir / "normal"
        if normal_dir.exists():
            for img_path in normal_dir.glob("*"):
                if img_path.suffix.lower() in ['.jpg', '.jpeg', '.png', '.bmp', '.tiff']:
                    # Original image
                    features = self.extract_enhanced_features(img_path)
                    features_list.append(features)
                    labels_list.append(0)
                    
                    # Augmented images (to increase dataset size)
                    try:
                        pil_image = Image.open(img_path)
                        
                        # Apply different augmentations
                        for aug_type in ['rotation', 'brightness', 'contrast']:
                            augmented = self.augment_image(pil_image, aug_type)
                            for aug_img in augmented[:2]:  # Limit to 2 per type
                                # Save temporarily and extract features
                                temp_path = self.data_dir / f"temp_aug_{img_path.stem}.png"
                                aug_img.save(temp_path)
                                
                                aug_features = self.extract_enhanced_features(temp_path)
                                features_list.append(aug_features)
                                labels_list.append(0)
                                
                                temp_path.unlink()  # Clean up
                    except Exception as e:
                        print(f"Augmentation failed for {img_path}: {e}")
                    
                    print(f"Processed normal: {img_path.name}")
        
        # Load Hashimoto images
        hashimoto_dir = self.data_dir / "hashimoto"
        if hashimoto_dir.exists():
            for img_path in hashimoto_dir.glob("*"):
                if img_path.suffix.lower() in ['.jpg', '.jpeg', '.png', '.bmp', '.tiff']:
                    # Original image
                    features = self.extract_enhanced_features(img_path)
                    features_list.append(features)
                    labels_list.append(1)
                    
                    # Augmented images
                    try:
                        pil_image = Image.open(img_path)
                        
                        for aug_type in ['rotation', 'brightness', 'contrast']:
                            augmented = self.augment_image(pil_image, aug_type)
                            for aug_img in augmented[:2]:  # Limit to 2 per type
                                temp_path = self.data_dir / f"temp_aug_{img_path.stem}.png"
                                aug_img.save(temp_path)
                                
                                aug_features = self.extract_enhanced_features(temp_path)
                                features_list.append(aug_features)
                                labels_list.append(1)
                                
                                temp_path.unlink()  # Clean up
                    except Exception as e:
                        print(f"Augmentation failed for {img_path}: {e}")
                    
                    print(f"Processed Hashimoto: {img_path.name}")
        
        if not features_list:
            raise ValueError("No images found")
        
        X = np.array(features_list)
        y = np.array(labels_list)
        
        print(f"Enhanced dataset loaded: {len(X)} samples (with augmentation)")
        print(f"Normal samples: {np.sum(y == 0)}")
        print(f"Hashimoto samples: {np.sum(y == 1)}")
        print(f"Feature dimensions: {X.shape[1]}")
        
        return X, y
    
    def train_enhanced_models(self, X, y):
        """
        Train multiple models with hyperparameter optimization
        """
        print("\nTraining enhanced models with optimization...")
        
        from sklearn.model_selection import train_test_split
        
        # Split data
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=0.2, random_state=42, stratify=y
        )
        
        # Feature selection
        selector = SelectKBest(f_classif, k=min(100, X.shape[1]))
        X_train_selected = selector.fit_transform(X_train, y_train)
        X_test_selected = selector.transform(X_test)
        
        print(f"Selected {X_train_selected.shape[1]} best features")
        
        # Test different scalers
        best_scaler_score = 0
        for scaler_name, scaler in self.scalers.items():
            X_train_scaled = scaler.fit_transform(X_train_selected)
            
            # Quick test with Random Forest
            rf = RandomForestClassifier(n_estimators=50, random_state=42)
            cv_scores = StratifiedKFold(n_splits=3, shuffle=True, random_state=42)
            
            from sklearn.model_selection import cross_val_score
            scores = cross_val_score(rf, X_train_scaled, y_train, cv=cv_scores)
            mean_score = np.mean(scores)
            
            if mean_score > best_scaler_score:
                best_scaler_score = mean_score
                self.best_scaler = scaler
                self.best_scaler_name = scaler_name
        
        print(f"Best scaler: {self.best_scaler_name} (CV score: {best_scaler_score:.3f})")
        
        # Scale data with best scaler
        X_train_scaled = self.best_scaler.fit_transform(X_train_selected)
        X_test_scaled = self.best_scaler.transform(X_test_selected)
        
        # Train and evaluate models
        results = {}
        
        for model_name, model in self.models.items():
            print(f"\nTraining {model_name}...")
            
            try:
                # Cross-validation
                cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
                cv_scores = cross_val_score(model, X_train_scaled, y_train, cv=cv, scoring='accuracy')
                
                # Train model
                model.fit(X_train_scaled, y_train)
                
                # Test predictions
                test_pred = model.predict(X_test_scaled)
                test_prob = model.predict_proba(X_test_scaled)[:, 1] if hasattr(model, 'predict_proba') else test_pred
                
                # Metrics
                test_accuracy = np.mean(test_pred == y_test)
                try:
                    test_auc = roc_auc_score(y_test, test_prob)
                except:
                    test_auc = test_accuracy  # Fallback
                
                results[model_name] = {
                    'model': model,
                    'cv_scores': cv_scores,
                    'cv_mean': np.mean(cv_scores),
                    'cv_std': np.std(cv_scores),
                    'test_accuracy': test_accuracy,
                    'test_auc': test_auc,
                    'test_predictions': test_pred,
                    'test_probabilities': test_prob,
                    'test_labels': y_test
                }
                
                print(f"CV Accuracy: {np.mean(cv_scores):.3f} (+/- {np.std(cv_scores)*2:.3f})")
                print(f"Test Accuracy: {test_accuracy:.3f}")
                print(f"Test AUC: {test_auc:.3f}")
                
            except Exception as e:
                print(f"Failed to train {model_name}: {e}")
                continue
        
        # Select best model
        if results:
            best_model_name = max(results.keys(), key=lambda k: results[k]['cv_mean'])
            self.best_model = results[best_model_name]['model']
            print(f"\nBest model: {best_model_name}")
        
        return results, X_test_scaled, y_test, selector
    
    def save_enhanced_model(self, results, selector):
        """
        Save enhanced model package
        """
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        
        if not results:
            print("No models to save!")
            return None, None
        
        # Best model based on CV accuracy
        best_model_name = max(results.keys(), key=lambda k: results[k]['cv_mean'])
        best_model = results[best_model_name]['model']
        
        # Enhanced model package
        model_package = {
            'classifier': best_model,
            'scaler': self.best_scaler,
            'feature_selector': selector,
            'backup_classifier': self.models.get('random_forest'),
            'feature_names': self.feature_names,
            'timestamp': timestamp,
            'best_model_name': best_model_name,
            'is_enhanced': True,
            'augmentation_used': True
        }
        
        model_path = self.output_dir / f"enhanced_hashimoto_model_{timestamp}.joblib"
        joblib.dump(model_package, model_path)
        
        # Enhanced metadata
        metadata = {
            'training_date': timestamp,
            'model_type': 'enhanced',
            'best_model': best_model_name,
            'feature_count': len(self.feature_names),
            'selected_features': selector.k_,
            'scaler_used': self.best_scaler_name,
            'augmentation_applied': True,
            'results': {
                name: {
                    'cv_mean': float(result['cv_mean']),
                    'cv_std': float(result['cv_std']),
                    'test_accuracy': float(result['test_accuracy']),
                    'test_auc': float(result['test_auc'])
                }
                for name, result in results.items()
            }
        }
        
        metadata_path = self.output_dir / f"enhanced_training_metadata_{timestamp}.json"
        with open(metadata_path, 'w') as f:
            json.dump(metadata, f, indent=2)
        
        print(f"\nEnhanced model saved to: {model_path}")
        print(f"Enhanced metadata saved to: {metadata_path}")
        
        return model_path, metadata_path

def run_enhanced_training():
    """
    Run enhanced training process
    """
    print("ENHANCED HASHIMOTO'S THYROIDITIS DETECTION TRAINING")
    print("=" * 55)
    
    trainer = EnhancedHashimotoTrainer("data", "models")
    
    try:
        # Load dataset with augmentation
        X, y = trainer.load_and_augment_dataset()
        
        # Train enhanced models
        results, X_test, y_test, selector = trainer.train_enhanced_models(X, y)
        
        # Save enhanced model
        model_path, metadata_path = trainer.save_enhanced_model(results, selector)
        
        print("\n" + "=" * 55)
        print("ENHANCED TRAINING COMPLETED!")
        print("=" * 55)
        print(f"Enhanced model with improved reliability saved")
        print(f"Model includes data augmentation and feature selection")
        print(f"Ready for use in the main application")
        
        return True
        
    except Exception as e:
        print(f"Enhanced training failed: {e}")
        return False

if __name__ == "__main__":
    run_enhanced_training()