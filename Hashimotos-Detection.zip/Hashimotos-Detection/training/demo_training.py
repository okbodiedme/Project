"""
Demo script to show training process with sample data
Creates synthetic sample images for demonstration purposes
"""

import numpy as np
import cv2
from PIL import Image
import os
from pathlib import Path
import random
from train_model import HashimotoModelTrainer

def create_sample_thyroid_image(image_type="normal", size=(224, 224)):
    """
    Create a synthetic thyroid ultrasound-like image for demonstration
    
    Args:
        image_type: "normal" or "hashimoto"
        size: Image dimensions
    
    Returns:
        PIL Image object
    """
    width, height = size
    
    # Create base image with ultrasound-like appearance
    image = np.zeros((height, width, 3), dtype=np.uint8)
    
    # Add background noise
    noise = np.random.normal(20, 10, (height, width))
    noise = np.clip(noise, 0, 255).astype(np.uint8)
    
    for channel in range(3):
        image[:, :, channel] = noise
    
    # Add thyroid-like structure
    center_x, center_y = width // 2, height // 2
    
    if image_type == "normal":
        # Normal thyroid: smooth, homogeneous appearance
        
        # Main thyroid shape
        cv2.ellipse(image, (center_x, center_y), (80, 60), 0, 0, 360, (60, 60, 60), -1)
        
        # Add smooth texture
        for i in range(20):
            x = random.randint(center_x - 60, center_x + 60)
            y = random.randint(center_y - 40, center_y + 40)
            radius = random.randint(3, 8)
            intensity = random.randint(55, 75)
            cv2.circle(image, (x, y), radius, (intensity, intensity, intensity), -1)
    
    else:  # hashimoto
        # Hashimoto's thyroid: heterogeneous, with irregular patterns
        
        # Main thyroid shape (slightly enlarged)
        cv2.ellipse(image, (center_x, center_y), (90, 70), 0, 0, 360, (50, 50, 50), -1)
        
        # Add heterogeneous texture
        for i in range(30):
            x = random.randint(center_x - 70, center_x + 70)
            y = random.randint(center_y - 50, center_y + 50)
            radius = random.randint(2, 12)
            intensity = random.randint(35, 85)
            cv2.circle(image, (x, y), radius, (intensity, intensity, intensity), -1)
        
        # Add some hypoechoic areas (darker regions)
        for i in range(10):
            x = random.randint(center_x - 60, center_x + 60)
            y = random.randint(center_y - 40, center_y + 40)
            radius = random.randint(5, 15)
            cv2.circle(image, (x, y), radius, (25, 25, 25), -1)
        
        # Add some irregular boundaries
        points = []
        for angle in range(0, 360, 30):
            radius_var = random.randint(-10, 15)
            x = center_x + int((85 + radius_var) * np.cos(np.radians(angle)))
            y = center_y + int((65 + radius_var) * np.sin(np.radians(angle)))
            points.append([x, y])
        
        points = np.array(points, np.int32)
        cv2.fillPoly(image, [points], (40, 40, 40))
    
    # Add some ultrasound-like artifacts
    # Vertical lines (beam artifacts)
    for i in range(3):
        x = random.randint(50, width - 50)
        cv2.line(image, (x, 0), (x, height), (80, 80, 80), 1)
    
    # Convert to PIL Image
    pil_image = Image.fromarray(image, 'RGB')
    
    return pil_image

def create_demo_dataset(num_normal=50, num_hashimoto=50):
    """
    Create a demo dataset with synthetic images
    
    Args:
        num_normal: Number of normal images to create
        num_hashimoto: Number of Hashimoto images to create
    """
    print("Creating demo dataset...")
    
    # Create directories
    data_dir = Path("data")
    normal_dir = data_dir / "normal"
    hashimoto_dir = data_dir / "hashimoto"
    
    normal_dir.mkdir(parents=True, exist_ok=True)
    hashimoto_dir.mkdir(parents=True, exist_ok=True)
    
    # Create normal images
    print(f"Creating {num_normal} normal thyroid images...")
    for i in range(num_normal):
        image = create_sample_thyroid_image("normal")
        image_path = normal_dir / f"normal_thyroid_{i+1:03d}.png"
        image.save(image_path)
        if (i + 1) % 10 == 0:
            print(f"  Created {i+1}/{num_normal} normal images")
    
    # Create Hashimoto images
    print(f"Creating {num_hashimoto} Hashimoto thyroid images...")
    for i in range(num_hashimoto):
        image = create_sample_thyroid_image("hashimoto")
        image_path = hashimoto_dir / f"hashimoto_thyroid_{i+1:03d}.png"
        image.save(image_path)
        if (i + 1) % 10 == 0:
            print(f"  Created {i+1}/{num_hashimoto} Hashimoto images")
    
    print(f"✅ Demo dataset created with {num_normal + num_hashimoto} images")
    print(f"📁 Data saved to: {data_dir.absolute()}")

def run_demo_training():
    """
    Run a complete demo training process
    """
    print("="*60)
    print("HASHIMOTO'S THYROIDITIS DETECTION - DEMO TRAINING")
    print("="*60)
    
    # Create demo dataset
    create_demo_dataset(num_normal=30, num_hashimoto=30)
    
    print("\n" + "="*60)
    print("STARTING MODEL TRAINING")
    print("="*60)
    
    try:
        # Initialize trainer
        trainer = HashimotoModelTrainer("data", "models")
        
        # Load dataset
        X, y, filenames = trainer.load_dataset()
        
        # Train models
        results, X_test, y_test = trainer.train_models(X, y)
        
        # Evaluate models
        trainer.evaluate_models(results)
        
        # Save models
        model_path, metadata_path = trainer.save_models(results)
        
        print("\n" + "="*60)
        print("DEMO TRAINING COMPLETED SUCCESSFULLY!")
        print("="*60)
        print(f"✅ Model saved to: {model_path}")
        print(f"✅ Metadata saved to: {metadata_path}")
        print("\nNow you can:")
        print("1. Restart the Streamlit app to use your trained model")
        print("2. Upload real thyroid images to test the model")
        print("3. Replace demo data with real medical images for better results")
        
        return True
        
    except Exception as e:
        print(f"❌ Demo training failed: {e}")
        return False

def clean_demo_data():
    """
    Clean up demo data files
    """
    import shutil
    
    data_dir = Path("data")
    if data_dir.exists():
        response = input("Delete demo dataset? (y/N): ").lower().strip()
        if response == 'y':
            shutil.rmtree(data_dir)
            print("🗑️ Demo dataset deleted")
        else:
            print("Demo dataset kept")

if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="Demo training for Hashimoto's detection")
    parser.add_argument("--action", choices=['create', 'train', 'clean'], 
                       default='train', help="Action to perform")
    parser.add_argument("--normal", type=int, default=30, 
                       help="Number of normal images to create")
    parser.add_argument("--hashimoto", type=int, default=30, 
                       help="Number of Hashimoto images to create")
    
    args = parser.parse_args()
    
    if args.action == 'create':
        create_demo_dataset(args.normal, args.hashimoto)
    elif args.action == 'train':
        run_demo_training()
    elif args.action == 'clean':
        clean_demo_data()