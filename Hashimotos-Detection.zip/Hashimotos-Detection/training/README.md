# Hashimoto's Thyroiditis Detection Model Training Guide

This guide explains how to train your own machine learning model for detecting Hashimoto's thyroiditis from thyroid ultrasound images.

## Prerequisites

### Required Packages
Make sure you have the following packages installed:
```bash
pip install scikit-learn pandas matplotlib seaborn joblib opencv-python pillow
```

### Data Organization

Your training data must be organized in the following directory structure:

```
data/
├── normal/
│   ├── normal_thyroid_1.jpg
│   ├── normal_thyroid_2.png
│   ├── normal_thyroid_3.jpg
│   └── ... (more normal thyroid images)
└── hashimoto/
    ├── hashimoto_1.jpg
    ├── hashimoto_2.png
    ├── hashimoto_3.jpg
    └── ... (more Hashimoto's thyroiditis images)
```

### Image Requirements

- **Formats**: JPG, JPEG, PNG, BMP, TIFF
- **Size**: Any size (images will be resized to 224x224 for processing)
- **Quality**: High-quality ultrasound images work best
- **Content**: Should show thyroid tissue clearly
- **Quantity**: Minimum 50 images per class, but 200+ per class is recommended

## Quick Start

1. **Prepare your data**:
   ```bash
   mkdir -p data/normal data/hashimoto
   # Copy your images into the appropriate folders
   ```

2. **Run training**:
   ```bash
   cd training
   python train_model.py
   ```

3. **Check results**:
   - Trained model will be saved in `models/` directory
   - Training metrics and visualizations will be displayed
   - Metadata file with training details will be created

## Training Process

### Feature Extraction

The training process extracts 100+ features from each image:

**Statistical Features (9 features)**:
- Mean, standard deviation, variance
- Median, min, max, range
- Skewness, kurtosis

**Texture Features (6 features)**:
- Gradients in X and Y directions
- Gradient magnitudes and variations
- Local texture patterns

**Edge Features (2 features)**:
- Edge density (number of edges per pixel)
- Edge distribution patterns

**Histogram Features (16 features)**:
- Intensity distribution analysis
- Brightness pattern characterization

**Shape Features (9 features)**:
- Image moments (geometric properties)
- Spatial distribution characteristics

**Local Binary Pattern Features (8 features)**:
- Local texture variations
- Surface pattern analysis

**Contrast and Homogeneity (2 features)**:
- Image contrast measurement
- Tissue homogeneity assessment

### Machine Learning Models

The system trains two models:

1. **Random Forest Classifier** (Primary):
   - 200 decision trees
   - Balanced class weights
   - Cross-validation optimized

2. **Logistic Regression** (Backup):
   - L2 regularization
   - Balanced class weights
   - Linear decision boundary

### Evaluation Metrics

Models are evaluated using:
- **Cross-validation accuracy** (5-fold stratified)
- **Test set accuracy**
- **Area Under Curve (AUC)**
- **Sensitivity and Specificity**
- **Confusion Matrix**

## Configuration Options

### Modifying Training Parameters

Edit `train_model.py` to customize:

```python
# Model parameters
'random_forest': RandomForestClassifier(
    n_estimators=200,        # Number of trees (50-500)
    max_depth=15,           # Tree depth (10-25)
    min_samples_split=5,    # Min samples to split (2-10)
    min_samples_leaf=2,     # Min samples per leaf (1-5)
    random_state=42,
    class_weight='balanced',
    n_jobs=-1
)
```

### Data Split Ratios

```python
# Training/test split
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2,    # 80% train, 20% test
    random_state=42, 
    stratify=y
)
```

## Output Files

After training, you'll get:

1. **Model File**: `models/hashimoto_model_YYYYMMDD_HHMMSS.joblib`
   - Contains trained classifier, scaler, and feature names
   - Ready to use in the main application

2. **Metadata File**: `models/training_metadata_YYYYMMDD_HHMMSS.json`
   - Training statistics and performance metrics
   - Feature importance information
   - Model configuration details

3. **Console Output**:
   - Real-time training progress
   - Cross-validation scores
   - Test set performance
   - Classification reports

## Using Your Trained Model

To use your trained model in the main application:

1. **Update model loading** in `model/model_utils.py`:

```python
def load_model():
    try:
        # Load your trained model
        model_path = "models/hashimoto_model_YYYYMMDD_HHMMSS.joblib"
        model_package = joblib.load(model_path)
        
        return model_package
    except Exception as e:
        # Fallback to demo model
        return create_model()
```

2. **Update prediction function** if needed to match your feature extraction.

## Data Collection Guidelines

### Image Quality Standards

**Good Images**:
- Clear thyroid boundaries
- Proper ultrasound settings
- Minimal artifacts
- Good contrast
- Standard ultrasound views

**Avoid**:
- Blurry or low-resolution images
- Images with excessive artifacts
- Non-thyroid ultrasound images
- Severely distorted images

### Medical Considerations

**Important**: This training framework is for research and educational purposes only:

- Ensure proper medical ethics approval
- De-identify all patient information
- Follow institutional guidelines
- Consult with medical professionals
- Validate results with clinical experts

### Data Balance

For best results:
- Aim for balanced datasets (similar numbers of normal and Hashimoto images)
- Include diverse patient populations
- Represent different ultrasound equipment
- Include various disease severities

## Troubleshooting

### Common Issues

1. **"No images found"**:
   - Check directory structure
   - Verify image file extensions
   - Ensure images are readable

2. **Low accuracy**:
   - Increase dataset size
   - Check image quality
   - Verify correct labeling
   - Adjust model parameters

3. **Memory errors**:
   - Reduce number of images for initial testing
   - Use smaller image sizes
   - Reduce model complexity

4. **Feature extraction errors**:
   - Check image formats
   - Verify OpenCV installation
   - Ensure images are not corrupted

### Performance Optimization

**For Large Datasets**:
- Use parallel processing (`n_jobs=-1`)
- Consider incremental learning
- Implement data batching
- Use feature selection

**For Better Accuracy**:
- Collect more training data
- Improve image quality
- Add data augmentation
- Tune hyperparameters
- Try ensemble methods

## Advanced Features

### Custom Feature Engineering

Add new features by modifying the `extract_features` method:

```python
def extract_features(self, image_path):
    # ... existing code ...
    
    # Add your custom features
    custom_features = your_feature_function(gray)
    features.extend(custom_features)
    feature_names.extend(['custom_1', 'custom_2', ...])
    
    return np.array(features)
```

### Model Ensemble

Combine multiple models for better performance:

```python
# In train_models method
ensemble_pred = (rf_pred + lr_pred) / 2  # Simple averaging
```

### Cross-validation Strategies

Experiment with different validation approaches:

```python
from sklearn.model_selection import GroupKFold, LeaveOneOut

# For patient-grouped validation
cv = GroupKFold(n_splits=5)
cv_scores = cross_val_score(model, X, y, cv=cv, groups=patient_ids)
```

## Support

For questions or issues:
1. Check the troubleshooting section
2. Verify your data format and quality
3. Review the training logs for error messages
4. Ensure all dependencies are properly installed

Remember: This is a research tool. Always validate results with medical professionals and follow appropriate ethical guidelines for medical AI research.