"""
Data preparation utilities for Hashimoto's thyroiditis detection training
Helps organize and validate training data
"""

import os
import shutil
from pathlib import Path
import cv2
import numpy as np
from PIL import Image
import json
from datetime import datetime

class DataPreparation:
    def __init__(self, source_dir, target_dir="data"):
        """
        Initialize data preparation tool
        
        Args:
            source_dir: Directory containing unsorted images
            target_dir: Directory where organized data will be stored
        """
        self.source_dir = Path(source_dir)
        self.target_dir = Path(target_dir)
        
        # Create target directories
        self.normal_dir = self.target_dir / "normal"
        self.hashimoto_dir = self.target_dir / "hashimoto"
        
        self.normal_dir.mkdir(parents=True, exist_ok=True)
        self.hashimoto_dir.mkdir(parents=True, exist_ok=True)
        
    def validate_image(self, image_path):
        """
        Validate if an image is suitable for training
        
        Args:
            image_path: Path to image file
            
        Returns:
            is_valid: Boolean indicating validity
            issues: List of issues found
        """
        issues = []
        
        try:
            # Check if file exists and is readable
            if not image_path.exists():
                issues.append("File does not exist")
                return False, issues
            
            # Try to open with PIL
            try:
                with Image.open(image_path) as img:
                    width, height = img.size
                    mode = img.mode
            except Exception as e:
                issues.append(f"Cannot open image: {e}")
                return False, issues
            
            # Check image dimensions
            if width < 50 or height < 50:
                issues.append(f"Image too small: {width}x{height}")
            
            if width > 5000 or height > 5000:
                issues.append(f"Image too large: {width}x{height}")
            
            # Check aspect ratio
            aspect_ratio = width / height
            if aspect_ratio < 0.2 or aspect_ratio > 5.0:
                issues.append(f"Unusual aspect ratio: {aspect_ratio:.2f}")
            
            # Check color mode
            if mode not in ['RGB', 'L', 'RGBA']:
                issues.append(f"Unsupported color mode: {mode}")
            
            # Try to read with OpenCV
            try:
                cv_img = cv2.imread(str(image_path))
                if cv_img is None:
                    issues.append("Cannot read with OpenCV")
            except Exception as e:
                issues.append(f"OpenCV error: {e}")
            
            # Check file size
            file_size = image_path.stat().st_size
            if file_size < 1000:  # Less than 1KB
                issues.append("File too small (possibly corrupted)")
            
            if file_size > 50 * 1024 * 1024:  # More than 50MB
                issues.append("File too large")
            
        except Exception as e:
            issues.append(f"Validation error: {e}")
        
        return len(issues) == 0, issues
    
    def organize_images_interactive(self):
        """
        Interactive tool to organize images into normal/hashimoto folders
        """
        print("Interactive Image Organization Tool")
        print("=" * 40)
        print("Commands:")
        print("  n - Mark as Normal")
        print("  h - Mark as Hashimoto")
        print("  s - Skip image")
        print("  q - Quit")
        print("=" * 40)
        
        image_files = []
        for ext in ['*.jpg', '*.jpeg', '*.png', '*.bmp', '*.tiff']:
            image_files.extend(self.source_dir.glob(ext))
            image_files.extend(self.source_dir.glob(ext.upper()))
        
        if not image_files:
            print("No images found in source directory!")
            return
        
        print(f"Found {len(image_files)} images to organize")
        
        organized_count = {'normal': 0, 'hashimoto': 0, 'skipped': 0}
        
        for i, img_path in enumerate(image_files):
            print(f"\n--- Image {i+1}/{len(image_files)} ---")
            print(f"File: {img_path.name}")
            
            # Validate image
            is_valid, issues = self.validate_image(img_path)
            if not is_valid:
                print("⚠️ Image validation issues:")
                for issue in issues:
                    print(f"  - {issue}")
                print("Skipping this image...")
                organized_count['skipped'] += 1
                continue
            
            # Show image info
            try:
                with Image.open(img_path) as img:
                    print(f"Size: {img.size[0]}x{img.size[1]}")
                    print(f"Mode: {img.mode}")
                    file_size = img_path.stat().st_size / 1024
                    print(f"File size: {file_size:.1f} KB")
            except:
                print("Could not read image details")
            
            # Get user input
            while True:
                choice = input("Classify as (n)ormal, (h)ashimoto, (s)kip, or (q)uit: ").lower().strip()
                
                if choice == 'q':
                    print("Quitting...")
                    self.print_summary(organized_count)
                    return
                
                elif choice == 'n':
                    self.copy_image(img_path, self.normal_dir)
                    organized_count['normal'] += 1
                    print(f"✅ Moved to normal folder")
                    break
                
                elif choice == 'h':
                    self.copy_image(img_path, self.hashimoto_dir)
                    organized_count['hashimoto'] += 1
                    print(f"✅ Moved to hashimoto folder")
                    break
                
                elif choice == 's':
                    organized_count['skipped'] += 1
                    print("⏭️ Skipped")
                    break
                
                else:
                    print("Invalid choice. Please enter n, h, s, or q.")
        
        print("\n🎉 Organization complete!")
        self.print_summary(organized_count)
    
    def copy_image(self, source_path, target_dir):
        """Copy image to target directory with unique name if needed"""
        target_path = target_dir / source_path.name
        
        # Handle duplicate names
        counter = 1
        while target_path.exists():
            stem = source_path.stem
            suffix = source_path.suffix
            target_path = target_dir / f"{stem}_{counter}{suffix}"
            counter += 1
        
        shutil.copy2(source_path, target_path)
    
    def print_summary(self, organized_count):
        """Print organization summary"""
        print("\n📊 Organization Summary:")
        print(f"Normal images: {organized_count['normal']}")
        print(f"Hashimoto images: {organized_count['hashimoto']}")
        print(f"Skipped images: {organized_count['skipped']}")
        total = sum(organized_count.values())
        print(f"Total processed: {total}")
        
        if organized_count['normal'] > 0 and organized_count['hashimoto'] > 0:
            ratio = organized_count['normal'] / organized_count['hashimoto']
            print(f"Normal:Hashimoto ratio: {ratio:.2f}:1")
            
            if ratio < 0.5 or ratio > 2.0:
                print("⚠️ Unbalanced dataset - consider collecting more images")
            else:
                print("✅ Reasonably balanced dataset")
    
    def batch_organize_by_filename(self, normal_keywords=None, hashimoto_keywords=None):
        """
        Organize images automatically based on filename patterns
        
        Args:
            normal_keywords: List of keywords indicating normal images
            hashimoto_keywords: List of keywords indicating Hashimoto images
        """
        if normal_keywords is None:
            normal_keywords = ['normal', 'healthy', 'regular', 'control']
        
        if hashimoto_keywords is None:
            hashimoto_keywords = ['hashimoto', 'thyroiditis', 'autoimmune', 'inflamed']
        
        print("Organizing images by filename...")
        
        image_files = []
        for ext in ['*.jpg', '*.jpeg', '*.png', '*.bmp', '*.tiff']:
            image_files.extend(self.source_dir.glob(ext))
            image_files.extend(self.source_dir.glob(ext.upper()))
        
        organized_count = {'normal': 0, 'hashimoto': 0, 'unknown': 0, 'invalid': 0}
        
        for img_path in image_files:
            # Validate image first
            is_valid, issues = self.validate_image(img_path)
            if not is_valid:
                print(f"❌ Invalid: {img_path.name} - {issues[0] if issues else 'Unknown error'}")
                organized_count['invalid'] += 1
                continue
            
            filename_lower = img_path.name.lower()
            
            # Check for normal keywords
            if any(keyword in filename_lower for keyword in normal_keywords):
                self.copy_image(img_path, self.normal_dir)
                organized_count['normal'] += 1
                print(f"✅ Normal: {img_path.name}")
            
            # Check for Hashimoto keywords
            elif any(keyword in filename_lower for keyword in hashimoto_keywords):
                self.copy_image(img_path, self.hashimoto_dir)
                organized_count['hashimoto'] += 1
                print(f"✅ Hashimoto: {img_path.name}")
            
            else:
                organized_count['unknown'] += 1
                print(f"❓ Unknown: {img_path.name}")
        
        print("\n📊 Batch Organization Results:")
        for category, count in organized_count.items():
            print(f"{category.title()}: {count}")
        
        if organized_count['unknown'] > 0:
            print(f"\n⚠️ {organized_count['unknown']} images could not be classified automatically.")
            print("Consider using interactive organization for these images.")
    
    def generate_dataset_report(self):
        """Generate a report about the current dataset"""
        report = {
            'generation_date': datetime.now().isoformat(),
            'normal_images': [],
            'hashimoto_images': [],
            'statistics': {}
        }
        
        # Analyze normal images
        for img_path in self.normal_dir.glob('*'):
            if img_path.suffix.lower() in ['.jpg', '.jpeg', '.png', '.bmp', '.tiff']:
                img_info = self.analyze_image(img_path)
                img_info['filename'] = img_path.name
                report['normal_images'].append(img_info)
        
        # Analyze Hashimoto images
        for img_path in self.hashimoto_dir.glob('*'):
            if img_path.suffix.lower() in ['.jpg', '.jpeg', '.png', '.bmp', '.tiff']:
                img_info = self.analyze_image(img_path)
                img_info['filename'] = img_path.name
                report['hashimoto_images'].append(img_info)
        
        # Calculate statistics
        report['statistics'] = {
            'normal_count': len(report['normal_images']),
            'hashimoto_count': len(report['hashimoto_images']),
            'total_count': len(report['normal_images']) + len(report['hashimoto_images']),
            'balance_ratio': len(report['normal_images']) / len(report['hashimoto_images']) if report['hashimoto_images'] else 0
        }
        
        # Save report
        report_path = self.target_dir / "dataset_report.json"
        with open(report_path, 'w') as f:
            json.dump(report, f, indent=2)
        
        print(f"📄 Dataset report saved to: {report_path}")
        return report
    
    def analyze_image(self, img_path):
        """Analyze a single image and return metadata"""
        try:
            with Image.open(img_path) as img:
                width, height = img.size
                mode = img.mode
                file_size = img_path.stat().st_size
            
            return {
                'width': width,
                'height': height,
                'mode': mode,
                'file_size': file_size,
                'aspect_ratio': width / height
            }
        except Exception as e:
            return {'error': str(e)}

def main():
    """
    Main function for data preparation
    """
    import argparse
    
    parser = argparse.ArgumentParser(description="Prepare data for Hashimoto's thyroiditis detection training")
    parser.add_argument("source_dir", help="Directory containing images to organize")
    parser.add_argument("--target", default="data", help="Target directory for organized data")
    parser.add_argument("--mode", choices=['interactive', 'batch', 'report'], 
                       default='interactive', help="Organization mode")
    
    args = parser.parse_args()
    
    if not Path(args.source_dir).exists():
        print(f"Error: Source directory '{args.source_dir}' does not exist!")
        return
    
    prep = DataPreparation(args.source_dir, args.target)
    
    if args.mode == 'interactive':
        prep.organize_images_interactive()
    elif args.mode == 'batch':
        prep.batch_organize_by_filename()
    elif args.mode == 'report':
        prep.generate_dataset_report()

if __name__ == "__main__":
    main()