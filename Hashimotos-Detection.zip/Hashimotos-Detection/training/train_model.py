"""
Training script for Hashimoto's thyroiditis detection model
Provides a comprehensive framework for training with real medical image data
"""

import numpy as np
import pandas as pd
import cv2
import os
from PIL import Image
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split, cross_val_score, StratifiedKFold
from sklearn.metrics import classification_report, confusion_matrix, roc_auc_score
import joblib
import matplotlib.pyplot as plt
import seaborn as sns
from pathlib import Path
import json
from datetime import datetime
import warnings
warnings.filterwarnings('ignore')

class HashimotoModelTrainer:
    def __init__(self, data_dir, output_dir="models"):
        """
        Initialize the model trainer
        
        Args:
            data_dir: Directory containing training images
            output_dir: Directory to save trained models
        """
        self.data_dir = Path(data_dir)
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(exist_ok=True)
        
        # Initialize models
        self.models = {
            'random_forest': RandomForestClassifier(
                n_estimators=200,
                max_depth=15,
                min_samples_split=5,
                min_samples_leaf=2,
                random_state=42,
                class_weight='balanced',
                n_jobs=-1
            ),
            'logistic_regression': LogisticRegression(
                random_state=42,
                class_weight='balanced',
                max_iter=1000
            )
        }
        
        self.scaler = StandardScaler()
        self.feature_names = []
        
    def extract_features(self, image_path):
        """
        Extract comprehensive features from medical image
        
        Args:
            image_path: Path to the image file
            
        Returns:
            features: Feature vector for the image
        """
        try:
            # Load and preprocess image
            image = cv2.imread(str(image_path))
            if image is None:
                raise ValueError(f"Could not load image: {image_path}")
            
            # Convert to RGB
            image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
            
            # Resize to standard size
            image = cv2.resize(image, (224, 224))
            
            # Convert to grayscale for feature extraction
            gray = cv2.cvtColor(image, cv2.COLOR_RGB2GRAY)
            
            features = []
            feature_names = []
            
            # 1. Statistical Features
            stats = [
                ('mean', np.mean(gray)),
                ('std', np.std(gray)),
                ('var', np.var(gray)),
                ('median', np.median(gray)),
                ('min', np.min(gray)),
                ('max', np.max(gray)),
                ('range', np.max(gray) - np.min(gray)),
                ('skewness', self._calculate_skewness(gray)),
                ('kurtosis', self._calculate_kurtosis(gray))
            ]
            
            for name, value in stats:
                features.append(value)
                feature_names.append(f'stat_{name}')
            
            # 2. Texture Features (Gradients)
            grad_x = cv2.Sobel(gray, cv2.CV_64F, 1, 0, ksize=3)
            grad_y = cv2.Sobel(gray, cv2.CV_64F, 0, 1, ksize=3)
            grad_mag = np.sqrt(grad_x**2 + grad_y**2)
            
            texture_features = [
                ('grad_x_mean', np.mean(np.abs(grad_x))),
                ('grad_y_mean', np.mean(np.abs(grad_y))),
                ('grad_x_std', np.std(grad_x)),
                ('grad_y_std', np.std(grad_y)),
                ('grad_mag_mean', np.mean(grad_mag)),
                ('grad_mag_std', np.std(grad_mag))
            ]
            
            for name, value in texture_features:
                features.append(value)
                feature_names.append(f'texture_{name}')
            
            # 3. Edge Features
            edges = cv2.Canny(gray, 50, 150)
            edge_density = np.sum(edges > 0) / edges.size
            edge_mean_dist = self._calculate_edge_distribution(edges)
            
            features.extend([edge_density, edge_mean_dist])
            feature_names.extend(['edge_density', 'edge_distribution'])
            
            # 4. Histogram Features
            hist, _ = np.histogram(gray, bins=32, range=(0, 256))
            hist = hist / np.sum(hist) if np.sum(hist) > 0 else hist
            
            for i, h in enumerate(hist[:16]):  # Use first 16 bins
                features.append(h)
                feature_names.append(f'hist_bin_{i}')
            
            # 5. Moments (Shape Features)
            moments = cv2.moments(gray)
            moment_features = [
                ('m00', moments.get('m00', 0)),
                ('m10', moments.get('m10', 0)),
                ('m01', moments.get('m01', 0)),
                ('m20', moments.get('m20', 0)),
                ('m11', moments.get('m11', 0)),
                ('m02', moments.get('m02', 0)),
                ('mu20', moments.get('mu20', 0)),
                ('mu11', moments.get('mu11', 0)),
                ('mu02', moments.get('mu02', 0))
            ]
            
            for name, value in moment_features:
                features.append(value)
                feature_names.append(f'moment_{name}')
            
            # 6. Local Binary Pattern Features (simplified)
            lbp_features = self._calculate_lbp_features(gray)
            for i, lbp in enumerate(lbp_features):
                features.append(lbp)
                feature_names.append(f'lbp_{i}')
            
            # 7. Contrast and Homogeneity
            contrast = self._calculate_contrast(gray)
            homogeneity = self._calculate_homogeneity(gray)
            
            features.extend([contrast, homogeneity])
            feature_names.extend(['contrast', 'homogeneity'])
            
            # Store feature names for first image
            if not self.feature_names:
                self.feature_names = feature_names
            
            return np.array(features)
            
        except Exception as e:
            print(f"Error extracting features from {image_path}: {e}")
            # Return zeros if feature extraction fails
            return np.zeros(len(self.feature_names) if self.feature_names else 100)
    
    def _calculate_skewness(self, image):
        """Calculate skewness of image intensity distribution"""
        mean_val = np.mean(image)
        std_val = np.std(image)
        if std_val == 0:
            return 0
        return np.mean(((image - mean_val) / std_val) ** 3)
    
    def _calculate_kurtosis(self, image):
        """Calculate kurtosis of image intensity distribution"""
        mean_val = np.mean(image)
        std_val = np.std(image)
        if std_val == 0:
            return 0
        return np.mean(((image - mean_val) / std_val) ** 4) - 3
    
    def _calculate_edge_distribution(self, edges):
        """Calculate mean distance between edge pixels"""
        edge_coords = np.where(edges > 0)
        if len(edge_coords[0]) < 2:
            return 0
        
        # Sample subset for efficiency
        if len(edge_coords[0]) > 1000:
            indices = np.random.choice(len(edge_coords[0]), 1000, replace=False)
            edge_coords = (edge_coords[0][indices], edge_coords[1][indices])
        
        distances = []
        for i in range(min(100, len(edge_coords[0]))):
            for j in range(i+1, min(i+10, len(edge_coords[0]))):
                dist = np.sqrt((edge_coords[0][i] - edge_coords[0][j])**2 + 
                              (edge_coords[1][i] - edge_coords[1][j])**2)
                distances.append(dist)
        
        return np.mean(distances) if distances else 0
    
    def _calculate_lbp_features(self, image):
        """Calculate simplified Local Binary Pattern features"""
        lbp_features = []
        
        # Simple 3x3 LBP calculation
        for i in range(1, image.shape[0]-1):
            for j in range(1, image.shape[1]-1):
                center = image[i, j]
                neighbors = [
                    image[i-1, j-1], image[i-1, j], image[i-1, j+1],
                    image[i, j+1], image[i+1, j+1], image[i+1, j],
                    image[i+1, j-1], image[i, j-1]
                ]
                
                binary_string = ''.join(['1' if neighbor >= center else '0' 
                                       for neighbor in neighbors])
                lbp_features.append(int(binary_string, 2))
        
        # Return histogram of LBP values
        hist, _ = np.histogram(lbp_features, bins=8, range=(0, 256))
        return hist / np.sum(hist) if np.sum(hist) > 0 else hist
    
    def _calculate_contrast(self, image):
        """Calculate image contrast"""
        return np.std(image)
    
    def _calculate_homogeneity(self, image):
        """Calculate image homogeneity"""
        # Simple homogeneity measure based on local variance
        kernel = np.ones((3, 3)) / 9
        local_mean = cv2.filter2D(image.astype(np.float32), -1, kernel)
        local_var = cv2.filter2D((image.astype(np.float32) - local_mean)**2, -1, kernel)
        return 1.0 / (1.0 + np.mean(local_var))
    
    def load_dataset(self):
        """
        Load dataset from directory structure
        Expected structure:
        data_dir/
        ├── normal/
        │   ├── image1.jpg
        │   ├── image2.jpg
        │   └── ...
        └── hashimoto/
            ├── image1.jpg
            ├── image2.jpg
            └── ...
        """
        print("Loading dataset...")
        
        features_list = []
        labels_list = []
        filenames_list = []
        
        # Load normal images (label = 0)
        normal_dir = self.data_dir / "normal"
        if normal_dir.exists():
            for img_path in normal_dir.glob("*"):
                if img_path.suffix.lower() in ['.jpg', '.jpeg', '.png', '.bmp', '.tiff']:
                    features = self.extract_features(img_path)
                    features_list.append(features)
                    labels_list.append(0)
                    filenames_list.append(str(img_path))
                    print(f"Processed normal: {img_path.name}")
        
        # Load Hashimoto images (label = 1)
        hashimoto_dir = self.data_dir / "hashimoto"
        if hashimoto_dir.exists():
            for img_path in hashimoto_dir.glob("*"):
                if img_path.suffix.lower() in ['.jpg', '.jpeg', '.png', '.bmp', '.tiff']:
                    features = self.extract_features(img_path)
                    features_list.append(features)
                    labels_list.append(1)
                    filenames_list.append(str(img_path))
                    print(f"Processed Hashimoto: {img_path.name}")
        
        if not features_list:
            raise ValueError("No images found in the specified directory structure")
        
        X = np.array(features_list)
        y = np.array(labels_list)
        
        print(f"Dataset loaded: {len(X)} images")
        print(f"Normal samples: {np.sum(y == 0)}")
        print(f"Hashimoto samples: {np.sum(y == 1)}")
        print(f"Feature dimensions: {X.shape[1]}")
        
        return X, y, filenames_list
    
    def train_models(self, X, y):
        """Train all models with cross-validation"""
        print("\nTraining models...")
        
        # Split data
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=0.2, random_state=42, stratify=y
        )
        
        # Scale features
        X_train_scaled = self.scaler.fit_transform(X_train)
        X_test_scaled = self.scaler.transform(X_test)
        
        results = {}
        
        for model_name, model in self.models.items():
            print(f"\nTraining {model_name}...")
            
            # Cross-validation
            cv_scores = cross_val_score(
                model, X_train_scaled, y_train, 
                cv=StratifiedKFold(n_splits=5, shuffle=True, random_state=42),
                scoring='accuracy'
            )
            
            # Train on full training set
            model.fit(X_train_scaled, y_train)
            
            # Test set evaluation
            test_pred = model.predict(X_test_scaled)
            test_prob = model.predict_proba(X_test_scaled)[:, 1]
            
            # Calculate metrics
            test_accuracy = np.mean(test_pred == y_test)
            test_auc = roc_auc_score(y_test, test_prob)
            
            results[model_name] = {
                'model': model,
                'cv_scores': cv_scores,
                'cv_mean': np.mean(cv_scores),
                'cv_std': np.std(cv_scores),
                'test_accuracy': test_accuracy,
                'test_auc': test_auc,
                'test_predictions': test_pred,
                'test_probabilities': test_prob,
                'test_labels': y_test
            }
            
            print(f"CV Accuracy: {np.mean(cv_scores):.3f} (+/- {np.std(cv_scores)*2:.3f})")
            print(f"Test Accuracy: {test_accuracy:.3f}")
            print(f"Test AUC: {test_auc:.3f}")
        
        return results, X_test_scaled, y_test
    
    def evaluate_models(self, results):
        """Generate comprehensive evaluation reports"""
        print("\n" + "="*50)
        print("MODEL EVALUATION RESULTS")
        print("="*50)
        
        for model_name, result in results.items():
            print(f"\n{model_name.upper()} RESULTS:")
            print("-" * 30)
            print(f"Cross-validation accuracy: {result['cv_mean']:.3f} ± {result['cv_std']:.3f}")
            print(f"Test accuracy: {result['test_accuracy']:.3f}")
            print(f"Test AUC: {result['test_auc']:.3f}")
            
            print("\nClassification Report:")
            print(classification_report(result['test_labels'], result['test_predictions'],
                                      target_names=['Normal', 'Hashimoto']))
            
            print("\nConfusion Matrix:")
            cm = confusion_matrix(result['test_labels'], result['test_predictions'])
            print(cm)
    
    def save_models(self, results):
        """Save trained models and metadata"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        
        # Save best model based on CV accuracy
        best_model_name = max(results.keys(), 
                             key=lambda k: results[k]['cv_mean'])
        best_model = results[best_model_name]['model']
        
        # Save model files
        model_package = {
            'classifier': best_model,
            'scaler': self.scaler,
            'backup_classifier': self.models['logistic_regression'],
            'feature_names': self.feature_names,
            'timestamp': timestamp,
            'best_model_name': best_model_name
        }
        
        model_path = self.output_dir / f"hashimoto_model_{timestamp}.joblib"
        joblib.dump(model_package, model_path)
        print(f"\nBest model saved to: {model_path}")
        
        # Save metadata
        metadata = {
            'training_date': timestamp,
            'best_model': best_model_name,
            'feature_count': len(self.feature_names),
            'feature_names': self.feature_names,
            'results': {
                name: {
                    'cv_mean': float(result['cv_mean']),
                    'cv_std': float(result['cv_std']),
                    'test_accuracy': float(result['test_accuracy']),
                    'test_auc': float(result['test_auc'])
                }
                for name, result in results.items()
            }
        }
        
        metadata_path = self.output_dir / f"training_metadata_{timestamp}.json"
        with open(metadata_path, 'w') as f:
            json.dump(metadata, f, indent=2)
        print(f"Training metadata saved to: {metadata_path}")
        
        return model_path, metadata_path

def main():
    """
    Main training function
    Usage: python train_model.py
    
    Make sure your data is organized as:
    data/
    ├── normal/
    │   ├── normal_image1.jpg
    │   └── ...
    └── hashimoto/
        ├── hashimoto_image1.jpg
        └── ...
    """
    
    # Configuration
    DATA_DIR = "data"  # Change this to your data directory
    OUTPUT_DIR = "models"
    
    # Check if data directory exists
    if not Path(DATA_DIR).exists():
        print(f"Data directory '{DATA_DIR}' not found!")
        print("\nPlease organize your data as:")
        print("data/")
        print("├── normal/")
        print("│   ├── normal_image1.jpg")
        print("│   └── ...")
        print("└── hashimoto/")
        print("    ├── hashimoto_image1.jpg")
        print("    └── ...")
        return
    
    try:
        # Initialize trainer
        trainer = HashimotoModelTrainer(DATA_DIR, OUTPUT_DIR)
        
        # Load dataset
        X, y, filenames = trainer.load_dataset()
        
        # Train models
        results, X_test, y_test = trainer.train_models(X, y)
        
        # Evaluate models
        trainer.evaluate_models(results)
        
        # Save models
        model_path, metadata_path = trainer.save_models(results)
        
        print("\n" + "="*50)
        print("TRAINING COMPLETED SUCCESSFULLY!")
        print("="*50)
        print(f"Model saved to: {model_path}")
        print(f"Metadata saved to: {metadata_path}")
        print("\nTo use the trained model in your application,")
        print("update the model loading code to use the saved model file.")
        
    except Exception as e:
        print(f"Training failed: {e}")
        raise

if __name__ == "__main__":
    main()