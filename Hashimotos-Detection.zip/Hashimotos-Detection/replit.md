# Hashimoto's Thyroiditis Detection System

## Overview

This is a Streamlit-based medical AI application designed for educational purposes to detect Hashimoto's thyroiditis from thyroid ultrasound images. The system uses a transfer learning approach with EfficientNetB0 as the base model and provides a user-friendly web interface for image analysis. The application emphasizes medical disclaimers and educational content to ensure responsible use.

## System Architecture

### Frontend Architecture
- **Framework**: Streamlit for web interface
- **Layout**: Wide layout with expandable sidebar navigation
- **Pages**: Multi-page application with navigation via selectbox
  - Image Analysis (main functionality)
  - About Hashimoto's (educational content)
  - Model Information
  - Privacy & Disclaimer
- **Visualization**: Plotly for interactive charts and confidence visualizations
- **State Management**: Streamlit session state for model loading and persistence

### Backend Architecture
- **ML Framework**: TensorFlow/Keras for deep learning
- **Model Architecture**: Transfer learning with EfficientNetB0 backbone
  - Pre-trained ImageNet weights (frozen base layers)
  - Custom classification head with dense layers and dropout
  - Binary classification (Normal vs Hashimoto's)
- **Image Processing**: OpenCV and PIL for image manipulation and preprocessing
- **Model Compilation**: Adam optimizer with categorical crossentropy loss

## Key Components

### Core Application (`app.py`)
- Main Streamlit application entry point
- Session state management for model loading
- Page routing and navigation
- Integration of all components

### Model Components (`model/model_utils.py`)
- **Transfer Learning Model**: EfficientNetB0 with custom classification head
- **Architecture**: 
  - Base: EfficientNetB0 (224x224x3 input)
  - Custom head: GlobalAveragePooling2D → Dense(128) → Dropout(0.5) → Dense(64) → Dropout(0.3) → Dense(2)
- **Model Loading**: Placeholder for trained weights loading
- **Problem Addressed**: Binary classification for medical image analysis with limited training data

### Image Processing (`utils/image_preprocessing.py`)
- **Validation**: Comprehensive image validation (format, size, aspect ratio)
- **Preprocessing**: Image normalization and resizing for model input
- **Constraints**: 
  - Min size: 100x100 pixels
  - Max size: 4000x4000 pixels
  - Aspect ratio: 0.3-3.0 range

### Visualization (`utils/visualization.py`)
- **Confidence Charts**: Plotly-based probability visualization
- **Interactive Elements**: Bar charts showing classification confidence
- **Error Handling**: Graceful fallback for visualization failures

### UI Components
- **Medical Disclaimer** (`components/disclaimer.py`): Comprehensive legal and ethical warnings
- **Educational Content** (`components/education.py`): Information about Hashimoto's thyroiditis

## Data Flow

1. **Image Upload**: User uploads thyroid ultrasound image via Streamlit interface
2. **Validation**: Image undergoes format, size, and quality validation
3. **Preprocessing**: Image is resized, normalized, and converted to model input format
4. **Model Inference**: Preprocessed image fed through EfficientNetB0-based model
5. **Post-processing**: Raw predictions converted to class probabilities
6. **Visualization**: Results displayed with confidence charts and interpretations
7. **Medical Disclaimer**: Prominent display of limitations and professional consultation requirements

## External Dependencies

### Core Dependencies
- **streamlit**: Web application framework
- **tensorflow**: Deep learning framework
- **numpy**: Numerical computing
- **opencv-python (cv2)**: Computer vision and image processing
- **PIL (Pillow)**: Image manipulation
- **matplotlib**: Static plotting (secondary visualization)
- **plotly**: Interactive visualizations

### Model Dependencies
- **tensorflow.keras.applications**: Pre-trained models (EfficientNetB0)
- **tensorflow.keras.layers**: Neural network layers
- **tensorflow.keras.models**: Model construction utilities

## Deployment Strategy

### Current State
- **Development Environment**: Designed for local/Replit deployment
- **Model Storage**: Currently uses runtime model creation (placeholder for trained weights)
- **Static Assets**: No external file dependencies beyond code

### Production Considerations
- **Model Persistence**: Requires integration with trained model weights storage
- **Scalability**: Streamlit suitable for prototype/demo, may need containerization for production
- **Medical Compliance**: Would require regulatory approval and additional security measures for clinical use
- **Performance**: Single-threaded Streamlit may need optimization for concurrent users

### Alternative Approaches Considered
- **FastAPI + React**: More scalable but complex for rapid prototyping
- **Gradio**: Simpler ML demos but less customizable
- **Chosen Approach**: Streamlit for rapid development and educational focus

### Pros and Cons
**Pros:**
- Rapid development and deployment
- Built-in UI components for ML applications
- Easy integration with Python ML stack
- Good for educational/demo purposes

**Cons:**
- Limited scalability for production use
- Single-threaded execution model
- Less control over UI/UX compared to custom web frameworks

## Training Framework

### Training Architecture
- **Training Script**: `training/train_model.py` - Comprehensive model training framework
- **Data Preparation**: `training/data_preparation.py` - Interactive and batch data organization tools
- **Demo Training**: `training/demo_training.py` - Synthetic data generation and demo training
- **Documentation**: `training/README.md` - Complete training guide

### Feature Engineering (100+ features)
- **Statistical Features**: Mean, variance, skewness, kurtosis
- **Texture Features**: Gradients, edge density, local patterns
- **Histogram Features**: Intensity distribution analysis
- **Shape Features**: Image moments, geometric properties
- **Local Binary Patterns**: Surface texture analysis
- **Contrast/Homogeneity**: Tissue uniformity measures

### Model Training Process
1. **Data Loading**: Automatic organization of normal/hashimoto image folders
2. **Feature Extraction**: Computer vision-based feature engineering
3. **Model Training**: Random Forest + Logistic Regression with cross-validation
4. **Evaluation**: Comprehensive metrics including AUC, sensitivity, specificity
5. **Model Persistence**: Automatic saving of trained models and metadata

### Training Data Requirements
- **Structure**: `data/normal/` and `data/hashimoto/` directories
- **Formats**: JPG, PNG, BMP, TIFF supported
- **Quality**: High-resolution thyroid ultrasound images
- **Quantity**: Minimum 50 per class, 200+ recommended for best results

## Changelog
- June 30, 2025. Initial setup
- June 30, 2025. Added comprehensive training framework with feature engineering and model persistence

## User Preferences

Preferred communication style: Simple, everyday language.