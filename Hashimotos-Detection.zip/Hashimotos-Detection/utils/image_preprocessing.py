import cv2
import numpy as np
from PIL import Image

def validate_image(image):
    """
    Validate uploaded image for medical analysis
    
    Args:
        image: PIL Image object
    
    Returns:
        is_valid: Boolean indicating if image is valid
        message: Validation message
    """
    try:
        # Check image mode
        if image.mode not in ['RGB', 'L', 'RGBA']:
            return False, "Image must be in RGB, grayscale, or RGBA format"
        
        # Check image size
        width, height = image.size
        if width < 100 or height < 100:
            return False, "Image too small. Minimum size: 100x100 pixels"
        
        if width > 4000 or height > 4000:
            return False, "Image too large. Maximum size: 4000x4000 pixels"
        
        # Check aspect ratio
        aspect_ratio = width / height
        if aspect_ratio < 0.3 or aspect_ratio > 3.0:
            return False, "Invalid aspect ratio. Image should be roughly rectangular"
        
        return True, "Image validation passed"
        
    except Exception as e:
        return False, f"Validation error: {str(e)}"

def preprocess_image(image):
    """
    Preprocess image for model input
    
    Args:
        image: PIL Image object
    
    Returns:
        processed_image: Preprocessed numpy array ready for model
    """
    try:
        # Convert to RGB if necessary
        if image.mode != 'RGB':
            image = image.convert('RGB')
        
        # Convert to numpy array
        img_array = np.array(image)
        
        # Resize to model input size
        img_resized = cv2.resize(img_array, (224, 224))
        
        # Enhance contrast
        img_enhanced = enhance_contrast(img_resized)
        
        # Apply subtle denoising
        img_denoised = cv2.bilateralFilter(img_enhanced, 9, 75, 75)
        
        # Normalize pixel values to [0, 1]
        img_normalized = img_denoised.astype(np.float32) / 255.0
        
        return img_normalized
        
    except Exception as e:
        raise Exception(f"Image preprocessing failed: {str(e)}")

def enhance_contrast(image):
    """
    Enhance image contrast using CLAHE (Contrast Limited Adaptive Histogram Equalization)
    
    Args:
        image: numpy array of image
    
    Returns:
        enhanced_image: Contrast enhanced image
    """
    try:
        # Convert to LAB color space
        lab = cv2.cvtColor(image, cv2.COLOR_RGB2LAB)
        
        # Apply CLAHE to L channel
        clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
        lab[:, :, 0] = clahe.apply(lab[:, :, 0])
        
        # Convert back to RGB
        enhanced = cv2.cvtColor(lab, cv2.COLOR_LAB2RGB)
        
        return enhanced
        
    except Exception as e:
        # If enhancement fails, return original image
        return image

def apply_data_augmentation(image, augment_type="random"):
    """
    Apply data augmentation techniques
    
    Args:
        image: numpy array of image
        augment_type: Type of augmentation to apply
    
    Returns:
        augmented_image: Augmented image
    """
    try:
        if augment_type == "rotation":
            # Random rotation (-15 to 15 degrees)
            angle = np.random.uniform(-15, 15)
            center = (image.shape[1] // 2, image.shape[0] // 2)
            rotation_matrix = cv2.getRotationMatrix2D(center, angle, 1.0)
            image = cv2.warpAffine(image, rotation_matrix, (image.shape[1], image.shape[0]))
        
        elif augment_type == "brightness":
            # Random brightness adjustment
            beta = np.random.uniform(-30, 30)
            image = cv2.convertScaleAbs(image, alpha=1.0, beta=beta)
        
        elif augment_type == "zoom":
            # Random zoom (0.9 to 1.1)
            zoom_factor = np.random.uniform(0.9, 1.1)
            h, w = image.shape[:2]
            new_h, new_w = int(h * zoom_factor), int(w * zoom_factor)
            
            # Resize and crop/pad to original size
            resized = cv2.resize(image, (new_w, new_h))
            
            if zoom_factor > 1.0:  # Crop
                start_h = (new_h - h) // 2
                start_w = (new_w - w) // 2
                image = resized[start_h:start_h + h, start_w:start_w + w]
            else:  # Pad
                pad_h = (h - new_h) // 2
                pad_w = (w - new_w) // 2
                image = cv2.copyMakeBorder(
                    resized, pad_h, pad_h, pad_w, pad_w, cv2.BORDER_REFLECT
                )
        
        return image
        
    except Exception as e:
        # If augmentation fails, return original image
        return image

def get_image_statistics(image):
    """
    Get statistical information about the image
    
    Args:
        image: numpy array of image
    
    Returns:
        stats: Dictionary containing image statistics
    """
    try:
        stats = {
            'mean': np.mean(image),
            'std': np.std(image),
            'min': np.min(image),
            'max': np.max(image),
            'shape': image.shape,
            'dtype': str(image.dtype)
        }
        return stats
    except Exception as e:
        return {'error': str(e)}
