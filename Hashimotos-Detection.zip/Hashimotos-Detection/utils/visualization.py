import plotly.graph_objects as go
import plotly.express as px
import matplotlib.pyplot as plt
import numpy as np
import cv2
from PIL import Image

def create_confidence_chart(class_probabilities):
    """
    Create a confidence chart showing class probabilities
    
    Args:
        class_probabilities: Array of class probabilities [normal, hashimoto]
    
    Returns:
        fig: Plotly figure object
    """
    try:
        classes = ['Normal', "Hashimoto's"]
        probabilities = class_probabilities
        
        # Create bar chart
        fig = go.Figure(data=[
            go.Bar(
                x=classes,
                y=probabilities,
                marker_color=['#2E8B57' if p == max(probabilities) else '#CD5C5C' 
                             for p in probabilities],
                text=[f'{p:.3f}' for p in probabilities],
                textposition='auto',
            )
        ])
        
        fig.update_layout(
            title="Classification Confidence",
            xaxis_title="Class",
            yaxis_title="Probability",
            yaxis=dict(range=[0, 1]),
            height=400,
            showlegend=False
        )
        
        return fig
        
    except Exception as e:
        # Return empty figure if visualization fails
        fig = go.Figure()
        fig.add_annotation(text=f"Visualization error: {str(e)}", 
                          xref="paper", yref="paper", x=0.5, y=0.5)
        return fig

def visualize_prediction(image, prediction, confidence):
    """
    Create visualization of prediction results
    
    Args:
        image: Original image
        prediction: Model prediction
        confidence: Prediction confidence
    
    Returns:
        fig: Matplotlib figure
    """
    try:
        fig, axes = plt.subplots(1, 2, figsize=(12, 5))
        
        # Original image
        axes[0].imshow(image)
        axes[0].set_title('Original Image')
        axes[0].axis('off')
        
        # Prediction overlay
        axes[1].imshow(image)
        
        # Add prediction text overlay
        color = 'red' if prediction == 1 else 'green'
        result_text = "Hashimoto's Detected" if prediction == 1 else "Normal"
        
        axes[1].text(0.02, 0.98, f'{result_text}\nConfidence: {confidence:.1f}%',
                    transform=axes[1].transAxes, fontsize=12,
                    verticalalignment='top', bbox=dict(boxstyle='round',
                    facecolor=color, alpha=0.8, edgecolor='white'))
        
        axes[1].set_title('Analysis Result')
        axes[1].axis('off')
        
        plt.tight_layout()
        return fig
        
    except Exception as e:
        # Return simple figure if visualization fails
        fig, ax = plt.subplots(figsize=(6, 4))
        ax.text(0.5, 0.5, f'Visualization error: {str(e)}', 
                ha='center', va='center', transform=ax.transAxes)
        ax.axis('off')
        return fig

def create_heatmap_overlay(image, attention_map=None):
    """
    Create attention heatmap overlay (placeholder for future implementation)
    
    Args:
        image: Original image
        attention_map: Attention/activation map from model
    
    Returns:
        overlaid_image: Image with heatmap overlay
    """
    try:
        if attention_map is None:
            # Create dummy attention map for demonstration
            h, w = image.shape[:2]
            attention_map = np.random.rand(h//4, w//4)
            attention_map = cv2.resize(attention_map, (w, h))
        
        # Normalize attention map
        attention_normalized = (attention_map - attention_map.min()) / (
            attention_map.max() - attention_map.min()
        )
        
        # Create heatmap
        heatmap = cv2.applyColorMap(
            (attention_normalized * 255).astype(np.uint8), 
            cv2.COLORMAP_JET
        )
        
        # Overlay on original image
        overlaid = cv2.addWeighted(image, 0.7, heatmap, 0.3, 0)
        
        return overlaid
        
    except Exception as e:
        # Return original image if overlay fails
        return image

def plot_training_history(history_dict=None):
    """
    Plot training history (placeholder for model training visualization)
    
    Args:
        history_dict: Training history dictionary
    
    Returns:
        fig: Plotly figure showing training metrics
    """
    try:
        # Dummy training history for demonstration
        if history_dict is None:
            epochs = list(range(1, 21))
            history_dict = {
                'accuracy': [0.6 + 0.02*i + 0.01*np.random.rand() for i in epochs],
                'val_accuracy': [0.58 + 0.015*i + 0.015*np.random.rand() for i in epochs],
                'loss': [1.2 - 0.05*i + 0.02*np.random.rand() for i in epochs],
                'val_loss': [1.25 - 0.04*i + 0.03*np.random.rand() for i in epochs]
            }
        
        fig = go.Figure()
        
        # Add accuracy traces
        fig.add_trace(go.Scatter(
            x=epochs, y=history_dict['accuracy'],
            mode='lines+markers', name='Training Accuracy',
            line=dict(color='blue')
        ))
        
        fig.add_trace(go.Scatter(
            x=epochs, y=history_dict['val_accuracy'],
            mode='lines+markers', name='Validation Accuracy',
            line=dict(color='lightblue')
        ))
        
        fig.update_layout(
            title="Model Training History",
            xaxis_title="Epoch",
            yaxis_title="Accuracy",
            height=400
        )
        
        return fig
        
    except Exception as e:
        # Return empty figure if plotting fails
        fig = go.Figure()
        fig.add_annotation(text=f"Plot error: {str(e)}", 
                          xref="paper", yref="paper", x=0.5, y=0.5)
        return fig

def create_roc_curve(y_true=None, y_scores=None):
    """
    Create ROC curve visualization
    
    Args:
        y_true: True labels
        y_scores: Prediction scores
    
    Returns:
        fig: Plotly figure showing ROC curve
    """
    try:
        # Dummy data for demonstration
        if y_true is None or y_scores is None:
            from sklearn.metrics import roc_curve, auc
            # Generate dummy data
            n_samples = 1000
            y_true = np.random.randint(0, 2, n_samples)
            y_scores = np.random.rand(n_samples)
            
            # Make it more realistic
            y_scores[y_true == 1] += 0.3
            y_scores = np.clip(y_scores, 0, 1)
        
        from sklearn.metrics import roc_curve, auc
        fpr, tpr, _ = roc_curve(y_true, y_scores)
        roc_auc = auc(fpr, tpr)
        
        fig = go.Figure()
        
        fig.add_trace(go.Scatter(
            x=fpr, y=tpr,
            mode='lines',
            name=f'ROC Curve (AUC = {roc_auc:.2f})',
            line=dict(color='darkorange', width=2)
        ))
        
        fig.add_trace(go.Scatter(
            x=[0, 1], y=[0, 1],
            mode='lines',
            name='Random Classifier',
            line=dict(color='navy', width=2, dash='dash')
        ))
        
        fig.update_layout(
            title='ROC Curve',
            xaxis_title='False Positive Rate',
            yaxis_title='True Positive Rate',
            height=400,
            xaxis=dict(range=[0, 1]),
            yaxis=dict(range=[0, 1])
        )
        
        return fig
        
    except Exception as e:
        # Return empty figure if plotting fails
        fig = go.Figure()
        fig.add_annotation(text=f"ROC curve error: {str(e)}", 
                          xref="paper", yref="paper", x=0.5, y=0.5)
        return fig
