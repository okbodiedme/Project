import streamlit as st
import plotly.graph_objects as go

def show_education_info():
    """
    Display educational information about Hashimoto's thyroiditis
    """
    st.header("📚 About Hashimoto's Thyroiditis")
    
    # Overview section
    st.subheader("What is Hashimoto's Thyroiditis?")
    st.markdown("""
    Hashimoto's thyroiditis, also known as **chronic lymphocytic thyroiditis** or **autoimmune thyroiditis**, 
    is the most common cause of hypothyroidism in developed countries. It is an autoimmune condition where 
    the body's immune system attacks the thyroid gland, leading to inflammation and gradual destruction 
    of thyroid tissue.
    """)
    
    # Key characteristics
    col1, col2 = st.columns(2)
    
    with col1:
        st.subheader("Key Characteristics")
        st.markdown("""
        **Autoimmune Nature:**
        - Body attacks its own thyroid tissue
        - Presence of thyroid antibodies
        - Lymphocytic infiltration of thyroid
        
        **Progressive Condition:**
        - Gradual onset of symptoms
        - May progress from normal to hypothyroid
        - Can have periods of hyperthyroid activity
        
        **Common Demographics:**
        - More common in women (8:1 ratio)
        - Peak incidence: 30-50 years old
        - Family history often present
        """)
    
    with col2:
        st.subheader("Symptoms")
        st.markdown("""
        **Early Symptoms:**
        - Fatigue and weakness
        - Weight gain
        - Cold intolerance
        - Dry skin and hair
        
        **Advanced Symptoms:**
        - Goiter (enlarged thyroid)
        - Depression
        - Memory problems
        - Muscle aches and stiffness
        - Constipation
        - Heavy menstrual periods
        """)
    
    # Diagnostic information
    st.subheader("Diagnosis")
    
    diagnostic_tabs = st.tabs(["Blood Tests", "Imaging", "Physical Examination"])
    
    with diagnostic_tabs[0]:
        st.markdown("""
        **Laboratory Tests:**
        
        **Thyroid Function Tests:**
        - **TSH (Thyroid Stimulating Hormone)**: Usually elevated
        - **Free T4**: Often low or low-normal
        - **Free T3**: May be low in advanced cases
        
        **Antibody Tests:**
        - **Anti-TPO (Thyroid Peroxidase Antibodies)**: Positive in 90-95% of cases
        - **Anti-Thyroglobulin Antibodies**: Positive in 60-70% of cases
        - **TSH Receptor Antibodies**: Usually negative (helps differentiate from Graves' disease)
        """)
        
        # Create a simple visualization of typical lab values
        create_lab_values_chart()
    
    with diagnostic_tabs[1]:
        st.markdown("""
        **Imaging Studies:**
        
        **Thyroid Ultrasound:**
        - **Echogenicity**: Typically hypoechoic (darker than normal)
        - **Echotexture**: Heterogeneous, coarse, or nodular pattern
        - **Vascularity**: May show increased blood flow
        - **Size**: Can be enlarged (goiter) or normal/small
        
        **Ultrasound Findings in Hashimoto's:**
        - Diffusely enlarged thyroid (early stages)
        - Hypoechoic echotexture
        - Heterogeneous appearance
        - Possible pseudonodules
        - Increased vascularity on Doppler
        
        **Other Imaging:**
        - **Thyroid Scintigraphy**: May show patchy uptake
        - **CT/MRI**: Rarely needed, used for complications
        """)
    
    with diagnostic_tabs[2]:
        st.markdown("""
        **Physical Examination Findings:**
        
        **Thyroid Palpation:**
        - Enlarged thyroid (goiter) - firm, rubbery texture
        - Possible tenderness
        - Irregular surface texture
        - May feel nodular
        
        **General Physical Signs:**
        - Dry, coarse skin
        - Hair loss or thinning
        - Bradycardia (slow heart rate)
        - Delayed reflexes
        - Periorbital puffiness
        - Weight gain
        """)
    
    # Treatment information
    st.subheader("Treatment")
    
    treatment_col1, treatment_col2 = st.columns(2)
    
    with treatment_col1:
        st.markdown("""
        **Hormone Replacement Therapy:**
        
        **Levothyroxine (T4):**
        - Standard treatment for hypothyroidism
        - Synthetic thyroid hormone
        - Daily oral medication
        - Dose adjusted based on TSH levels
        
        **Treatment Goals:**
        - Normalize TSH levels
        - Relieve symptoms
        - Prevent complications
        - Maintain quality of life
        """)
    
    with treatment_col2:
        st.markdown("""
        **Monitoring and Follow-up:**
        
        **Regular Testing:**
        - TSH levels every 6-8 weeks initially
        - Annual monitoring once stable
        - Dose adjustments as needed
        
        **Lifestyle Considerations:**
        - Consistent medication timing
        - Awareness of drug interactions
        - Regular exercise
        - Balanced diet
        - Stress management
        """)
    
    # Prognosis and complications
    st.subheader("Prognosis and Complications")
    
    prognosis_tabs = st.tabs(["Prognosis", "Complications", "Associated Conditions"])
    
    with prognosis_tabs[0]:
        st.markdown("""
        **Overall Prognosis:**
        - Excellent with proper treatment
        - Normal life expectancy
        - Symptoms typically resolve with hormone replacement
        - Lifelong condition requiring ongoing management
        
        **Factors Affecting Prognosis:**
        - Early diagnosis and treatment
        - Patient compliance with medication
        - Presence of other autoimmune conditions
        - Severity of thyroid destruction
        """)
    
    with prognosis_tabs[1]:
        st.markdown("""
        **Potential Complications:**
        
        **Untreated Hypothyroidism:**
        - Myxedema coma (rare, life-threatening)
        - Heart problems
        - Infertility
        - Birth defects (if pregnant)
        
        **Other Complications:**
        - Goiter complications (rare)
        - Increased cardiovascular risk
        - Depression and cognitive issues
        - Pregnancy complications
        """)
    
    with prognosis_tabs[2]:
        st.markdown("""
        **Associated Autoimmune Conditions:**
        
        **Common Associations:**
        - Type 1 Diabetes
        - Celiac Disease
        - Rheumatoid Arthritis
        - Addison's Disease
        - Vitiligo
        - Pernicious Anemia
        
        **Screening Recommendations:**
        - Regular monitoring for associated conditions
        - Family history assessment
        - Symptom awareness
        - Appropriate testing when indicated
        """)
    
    # Important notes
    st.markdown("---")
    st.info("""
    **Important Notes:**
    - This information is for educational purposes only
    - Always consult with healthcare professionals for diagnosis and treatment
    - Individual cases may vary significantly
    - Regular medical follow-up is essential
    """)

def create_lab_values_chart():
    """
    Create a chart showing typical lab values in Hashimoto's thyroiditis
    """
    # Sample data for visualization
    tests = ['TSH', 'Free T4', 'Free T3', 'Anti-TPO', 'Anti-Tg']
    normal_ranges = [100, 100, 100, 10, 10]  # Normalized to 100% for normal
    hashimoto_typical = [300, 60, 70, 400, 250]  # Typical values in Hashimoto's
    
    fig = go.Figure()
    
    # Normal range bars
    fig.add_trace(go.Bar(
        name='Normal Range',
        x=tests,
        y=normal_ranges,
        marker_color='lightblue',
        opacity=0.7
    ))
    
    # Hashimoto's typical values
    fig.add_trace(go.Bar(
        name="Typical in Hashimoto's",
        x=tests,
        y=hashimoto_typical,
        marker_color='lightcoral',
        opacity=0.8
    ))
    
    fig.update_layout(
        title="Typical Laboratory Values Comparison",
        xaxis_title="Laboratory Tests",
        yaxis_title="Relative Values (%)",
        barmode='group',
        height=400,
        legend=dict(
            yanchor="top",
            y=0.99,
            xanchor="left",
            x=0.01
        )
    )
    
    fig.add_annotation(
        text="* Values shown are relative and for illustration only",
        xref="paper", yref="paper",
        x=0.5, y=-0.1,
        showarrow=False,
        font=dict(size=10)
    )
    
    st.plotly_chart(fig, use_container_width=True)
    
    st.caption("""
    **Chart Explanation:**
    - TSH: Typically elevated (often >10 mIU/L)
    - Free T4: Often low or low-normal
    - Free T3: May be low in advanced cases
    - Anti-TPO: Markedly elevated (>200 IU/mL often indicates Hashimoto's)
    - Anti-Thyroglobulin: Often elevated but less specific
    """)
