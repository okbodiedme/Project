import streamlit as st

def show_medical_disclaimer():
    """
    Display comprehensive medical disclaimer
    """
    st.header("🚨 Medical Disclaimer & Privacy Information")
    
    st.markdown("""
    ## Medical Disclaimer
    
    **IMPORTANT: READ CAREFULLY BEFORE USING THIS APPLICATION**
    
    ### Purpose and Limitations
    
    This application is designed for **educational and research purposes only**. It is NOT intended for:
    - Clinical diagnosis
    - Medical decision making
    - Patient treatment planning
    - Replacement of professional medical advice
    
    ### Professional Medical Consultation Required
    
    **Always consult with qualified healthcare professionals for:**
    - Proper medical diagnosis
    - Treatment recommendations
    - Clinical interpretation of medical images
    - Health-related decisions
    
    The AI system provided here should **NEVER** be used as the sole basis for medical decisions.
    
    ### AI System Limitations
    
    This artificial intelligence tool:
    - Has not been cleared or approved by regulatory authorities (FDA, CE marking, etc.)
    - May produce false positive or false negative results
    - Performance may vary with different imaging equipment and techniques
    - Has been trained on limited datasets that may not represent all populations
    - Cannot replace the expertise of trained medical professionals
    
    ### User Responsibilities
    
    By using this application, you acknowledge that:
    - You understand this tool is for educational purposes only
    - You will not use results for clinical decision making
    - You will seek appropriate professional medical advice
    - You understand the limitations and potential inaccuracies of AI systems
    
    ---
    
    ## Privacy and Data Protection
    
    ### Image Processing
    - **Local Processing**: All image analysis is performed locally on our servers
    - **No Permanent Storage**: Uploaded images are not permanently stored
    - **Temporary Processing**: Images are held in memory only during analysis
    - **Automatic Deletion**: All data is automatically cleared after analysis
    
    ### Data Security
    - **Encryption**: All data transmission is encrypted using industry-standard protocols
    - **No Personal Information**: We do not collect personal or identifying information
    - **HIPAA Considerations**: This system is not HIPAA-compliant for clinical use
    - **Research Use**: Do not upload images containing patient identifying information
    
    ### Recommended Practices
    
    When using this tool:
    1. **Remove Patient Identifiers**: Ensure images contain no patient identifying information
    2. **Institutional Approval**: Obtain appropriate institutional approval if required
    3. **Consent**: Ensure proper consent for research or educational use
    4. **De-identification**: Follow proper de-identification procedures
    
    ---
    
    ## Technical Information
    
    ### Model Performance
    - **Training Data**: Limited dataset of thyroid ultrasound images
    - **Validation**: Performance metrics based on specific test conditions
    - **Generalization**: May not generalize to all imaging protocols or populations
    - **Updates**: Model performance may change with updates
    
    ### Known Limitations
    - Requires high-quality ultrasound images
    - Performance varies with image quality and acquisition parameters
    - May not detect all cases of Hashimoto's thyroiditis
    - May produce false positives in presence of other thyroid conditions
    
    ---
    
    ## Legal Disclaimer
    
    ### Limitation of Liability
    The developers, contributors, and hosting organization:
    - Provide this tool "as is" without warranty of any kind
    - Are not liable for any direct, indirect, or consequential damages
    - Do not guarantee accuracy, reliability, or fitness for any purpose
    - Are not responsible for any medical decisions made using this tool
    
    ### Regulatory Status
    This application:
    - Has not undergone regulatory review or approval
    - Is not intended as a medical device
    - Should not be used in clinical settings
    - Is provided for educational and research purposes only
    
    ### Reporting Issues
    If you encounter technical issues or have concerns about the application:
    - Report technical bugs through appropriate channels
    - Do not rely on the application if you suspect technical problems
    - Seek alternative professional evaluation for medical concerns
    
    ---
    
    **By continuing to use this application, you acknowledge that you have read, understood, and agree to these terms and limitations.**
    """)
    
    # Acceptance checkbox
    disclaimer_accepted = st.checkbox(
        "I have read and understood the medical disclaimer and privacy information",
        help="You must accept these terms to continue using the application"
    )
    
    if disclaimer_accepted:
        st.success("✅ Disclaimer acknowledged. You may proceed to use the application for educational purposes.")
    else:
        st.warning("⚠️ Please read and accept the disclaimer before using the application.")
    
    return disclaimer_accepted
